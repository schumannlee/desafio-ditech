<div id="menu">
	<span>MENU</span>
</div>
<nav>
	<a href="index.php">
		<div>Acessar</div></a>
	<a href="cadastro.php">
		<div>Cadastrar</div></a>
	<a href="contato.php">
		<div>Contato</div></a>
</nav>