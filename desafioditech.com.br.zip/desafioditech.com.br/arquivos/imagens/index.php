<script type="text/javascript">
	alert("Acesso restrito.");
	history.go(-1);
</script>